/***************************************************************/
/*             HW#10 : 가상함수와 추상클래스                                */
/*  작성자 : 배용호                    날짜 : 2023년 6월 4일  */
/*                                                                                     */
/* 문제 정의 : 다음 추상 클래스 Calculator를 상속받아 GoodCalc 클래스를 구현하라.
class Calculator {
public:
virtual int add(int a, int b) = 0; // 두 정수의 합 리턴
virtual int subtract(int a, int b) = 0; // 두 정수의 차 리턴
virtual double average(int a [], int size) = 0; // 배열 a의 평균 리턴. size는 배열의 크기
};
int main() {
int a[] = {1,2,3,4,5};
Calculator *p = new GoodCalc();
cout << p→add(2, 3) << endl;
cout << p→subtract(2, 3) << endl;
cout << p→average(a, 5) << endl;
delete p;
}
실행화면
5
-1
3                          */
/*                - - - - - - -                                                      */
/***************************************************************/
#include<iostream>
#include<string>
using namespace std;


class Calculator {
public:
    virtual int add(int a, int b) = 0; // 두 정수의 합 리턴
    virtual int subtract(int a, int b) = 0; // 두 정수의 차 리턴
    virtual double average(int a [], int size) = 0; // 배열 a의 평균 리턴. size는 배열의 크기
};

class GoodCalc : public Calculator{
public:
    virtual int add(int a, int b){
        return a+b;
    } // 두 정수의 합 리턴
    virtual int subtract(int a, int b){
        return a-b;
    } // 두 정수의 차 리턴
    virtual double average(int a [], int size){
        int total=0;
        for(int i=0;i<size;i++){
            total+=a[i];
        }
        return total/size;
    } // 배열 a의 평균 리턴. size는 배열의 크기
};

int main() {
    int a[] = {1,2,3,4,5};
    /*클래스형변환*/
    Calculator *p = new GoodCalc();
    cout << p->add(2, 3) << endl;
    cout << p->subtract(2, 3) << endl;
    cout << p->average(a, 5) << endl;
    delete p;
}
